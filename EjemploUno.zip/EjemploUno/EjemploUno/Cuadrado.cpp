#include "StdAfx.h"
#include "Cuadrado.h" //Permite utilizar la clase


Cuadrado::Cuadrado(void)
{
}
//metodos de acceso
int Cuadrado::Get_lado()
{
	return lado; // Devuelve el atributo lado de la clase 
}
void Cuadrado::Set_lado(int l)
{
	lado=l; //Asigna el valor de l al atributo lado
}
void Cuadrado::Set_area(int a)
{
	area=a; //Asigna el valor de l al atributo lado
}
	//otros metodos
int Cuadrado::Calcular()
{
	area=lado*lado;
	return area;
}
