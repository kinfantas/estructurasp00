#pragma once

class Cuadrado
{
private: //atributos
	int lado;
	int area;
public: //metodos
	Cuadrado(void); // Constructor
	//metodo de acceso y por estilo de programacion Scrum Master
	int Get_lado();  //Traer
	void Set_lado(int l);  //Coloca
	void Set_area(int a);
	//otros metodos
	int Calcular();
};

