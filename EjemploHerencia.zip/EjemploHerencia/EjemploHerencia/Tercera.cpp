#include "StdAfx.h"
#include "Tercera.h"

Tercera::Tercera(void){}
Tercera::~Tercera(void){}
 void Tercera::f (void) { i=j=2;}
