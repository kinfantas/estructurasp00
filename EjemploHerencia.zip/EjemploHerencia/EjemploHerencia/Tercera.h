#pragma once
#include "Primera.h"
#include "Segunda.h"
#include "stdafx.h"
#include <iostream>

using namespace std;

class Tercera: public Segunda {
public:
	 Tercera(void);
	~Tercera(void);
	 void f (void);
}; 