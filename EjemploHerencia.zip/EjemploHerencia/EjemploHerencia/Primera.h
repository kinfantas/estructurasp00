#pragma once

class Primera {
protected:
 int i, j;
public:
 Primera(); 
 Primera(int a, int b);
 ~Primera(void);
 void Entra_ij(int a, int b);
 void Muestra_ij (void);
}; 
