#include "StdAfx.h"
#include "Primera.h"
#include <iostream>

using namespace std;

 Primera::Primera() {i=j=0;}
 Primera::Primera(int a, int b) {i=a; j=b;}
 Primera::~Primera(void){}
 void Primera::Entra_ij(int a, int b) {i=a; j=b;}
 void Primera::Muestra_ij (void) {cout << "\n" << i << " " << j;}

