#pragma once
#include "Primera.h"
#include "stdafx.h"
#include <iostream>

using namespace std;

class Segunda: public Primera {
	private:
 int k;
public:
	Segunda(void);
	~Segunda(void);
 void Entra_k(int a);
 void Muestra_k (void);
}; 