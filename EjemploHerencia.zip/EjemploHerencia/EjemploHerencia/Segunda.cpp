#include "StdAfx.h"
#include "Segunda.h"


Segunda::Segunda(void){}
Segunda::~Segunda(void){}
 void Segunda::Entra_k(int a) {k=a;}
 void Segunda::Muestra_k (void) {cout << "\n" << k;}