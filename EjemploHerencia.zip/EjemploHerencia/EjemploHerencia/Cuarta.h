#pragma once
class Cuarta
{
public:
	Cuarta(void);
	~Cuarta(void);
};

