// EjemploHerencia.cpp : Defines the entry point for the console application.
//

// Programa: Herencia Simple
// Fichero: HER_SIM1.CPP
#include "stdafx.h"
#include "Primera.h"
#include "Segunda.h"
#include "Tercera.h"
#include "conio.h"
#include <iostream>

using namespace std;

// Se define una clase sencilla
void main (void)
{
 Primera P(1,2);
 Segunda S;
 Tercera T;
 S.Entra_ij(3,4);
 S.Entra_k(5);
 P.Muestra_ij(); // Saca 1 2
 S.Muestra_ij(); // Saca 3 4
 S.Muestra_k(); // Saca 5
 T.f();
 T.Muestra_ij(); // Saca 2 2
 T.Entra_k(3);
 T.Muestra_k(); // Saca 3
 S.Muestra_k(); // Saca 5
 T.Entra_ij(5,6);
 T.Muestra_ij(); // Saca 5 6
 P.Muestra_ij(); // Saca 1 2
 getch();
} 