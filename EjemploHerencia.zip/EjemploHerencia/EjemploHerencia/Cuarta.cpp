#include "StdAfx.h"
#include "Cuarta.h"


Cuarta::Cuarta(void)
{
}


Cuarta::~Cuarta(void)
{
}
