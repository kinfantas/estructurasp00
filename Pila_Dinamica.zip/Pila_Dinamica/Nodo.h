#pragma once
#include <iostream>
#include <string>
using namespace std;
class Nodo
{
public:
	int dato;
	string nombre;
	Nodo* sig;
};

